/*
Crear un programa en Java que permita al usuario ingresar un archivo de texto que contenga una lista de palabras y luego 
muestre en pantalla la cantidad de veces que aparece cada palabra en el archivo, utilizando un mapa para llevar un registro 
de las repeticiones. El programa debe ignorar los caracteres especiales (como comas y puntos) y las palabras comunes (como "el" o "la"). 
Además, el programa debe permitir al usuario guardar la lista de palabras y sus repeticiones en un archivo de texto.
 */
package conteoproyecto;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class App {
    public static void main(String[] args) {
        
        String name="frases.txt";
        
        Map<String, Integer> mapa = new HashMap<>();
        
        BufferedReader br=null;
        BufferedWriter bw=null;
        
        String frase=new String("");
        
        try{
            br=new BufferedReader(new FileReader(name));
            
            frase=br.readLine();
            String pbnull=br.readLine();
            
            while(pbnull != null){
                frase += br.readLine();
                
                pbnull=br.readLine();
            }
            System.out.println(frase);
        }catch (IOException io){
            System.out.println(io.toString());
        }finally{
            try{
                if(br!=null){
                    br.close();
                }
            }catch (IOException io){
                System.out.println(io.toString());
            }
        }
        
        devuelveMapa(mapa,frase);
        mostrarPalabras(mapa);
        
        String palabrasaEscribir= new String("");
        
        try{
            bw=new BufferedWriter(new FileWriter(new File("mapa.txt")));
            palabrasaEscribir= escribirPalabras(mapa);
            bw.write(palabrasaEscribir);
        }catch (IOException io){
            System.out.println(io.toString());
        }finally{
            try{
                if(bw!=null){
                    bw.close();
                }
            }catch (IOException io){
                System.out.println(io.toString());
            }
        }
    }
    
    public static void devuelveMapa(Map<String, Integer> mapa, String frase){
        
        String fraseModificada=frase.replace('.', '\b');
        fraseModificada= fraseModificada.replace(',', '\b');
        fraseModificada= fraseModificada.replace('"', '\b');
        fraseModificada= fraseModificada.replace(')', '\b');
        fraseModificada= fraseModificada.replace('(', '\b');
        
        String[] vector= fraseModificada.split(" ");
        
        for (String token : vector) {
            String palabra = token.toLowerCase();
            if (mapa.containsKey(palabra)) {
                int conteo = mapa.get(palabra);
                mapa.put(palabra, conteo + 1);
            } else {
                mapa.put(palabra, 1);
            }
        }
    }
    
    public static void mostrarPalabras(Map<String, Integer> mapa){
        Set<String> palabrasOrdenadas=new TreeSet<>(mapa.keySet());         //creo un treeSet del mapa con las palabras
        
        for(String key:palabrasOrdenadas){                                  //con un foreach se va imprimiendo en pantalla
            System.out.println(key + "\t" + mapa.get(key));                 // en el formato de key y value
        }
    }
    
    public static String escribirPalabras(Map<String, Integer> mapa){
        Set<String> palabrasOrdenadas=new TreeSet<>(mapa.keySet());         //creo un treeSet del mapa con las palabras
        
        String palabra=new String("");
        
        for(String key:palabrasOrdenadas){                                  //con un foreach se va imprimiendo en pantalla
            palabra += key + "\t" + mapa.get(key) + "\n";                // en el formato de key y value
        }
        return palabra;
    }
}
